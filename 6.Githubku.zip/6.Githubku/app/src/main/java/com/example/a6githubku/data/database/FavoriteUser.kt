package com.example.a6githubku.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "favorite_user")
data class FavoriteUser(
    @PrimaryKey
    val login: String,
    val id: String,
    val avatar_url: String
): Serializable