//package com.example.a5githubku.favorite
//
//import android.app.Application
//import androidx.lifecycle.LiveData
//import com.example.a5githubku.data.database.FavoriteDatabase
//import com.example.a5githubku.data.database.FavoriteUser
//import com.example.a5githubku.data.database.FavoriteUserDao
//import java.util.concurrent.ExecutorService
//import java.util.concurrent.Executors
//
//class FavoriteRepository(application: Application) {
//    private val mFavoriteUserDao: FavoriteUserDao
//    private val executorService: ExecutorService = Executors.newSingleThreadExecutor()
//
//    init {
//        val db = FavoriteDatabase.getDatabase(application)
//        mFavoriteUserDao = db.favoriteUserDao()
//    }
//    fun getAllFavorite(): LiveData<List<FavoriteUser>> = mFavoriteUserDao.getAllFavorite()
//
//    fun insert(favoriteUser: FavoriteUser) {
//        executorService.execute { mFavoriteUserDao.insert(favoriteUser) }
//    }
//
//    fun getFavoriteByUsername(username:String) : LiveData<FavoriteUser> = mFavoriteUserDao.getFavoriteByUsername(username)
//
//    fun delete(favoriteUser: FavoriteUser) {
//        executorService.execute { mFavoriteUserDao.delete(favoriteUser) }
//    }
//}