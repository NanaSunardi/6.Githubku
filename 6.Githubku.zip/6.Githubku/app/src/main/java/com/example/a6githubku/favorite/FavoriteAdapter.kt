package com.example.a6githubku.favorite

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.example.a6githubku.data.database.FavoriteUser
import com.example.a6githubku.databinding.ActivityFavoriteBinding
import com.example.a6githubku.databinding.ItemUserBinding

class FavoriteAdapter : RecyclerView.Adapter<FavoriteAdapter.FavoriteViewHolder>() {

    private val list = ArrayList<FavoriteUser>()

    private var onItemClickCallback: OnItemClickCallback? = null
    fun setOnItemClickCallback (onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    fun setList(users: ArrayList<FavoriteUser>) {
        list.clear()
        list.addAll(users)
        notifyDataSetChanged()
    }

    inner class FavoriteViewHolder(val binding: ItemUserBinding) : RecyclerView.ViewHolder(binding.root){
        fun bind(user: FavoriteUser) {
            binding.root.setOnClickListener {
                onItemClickCallback?.onItemClicked(user)
            }
            binding.tvItem.text = "${user.id}"
            Glide.with(binding.imgItemPhoto.context)
                .load(user.avatar_url)
                .into(binding.imgItemPhoto)

//            binding.apply {
//                Glide.with(itemView)
//                    .load(user.avatar_url)
//                    .transition(DrawableTransitionOptions.withCrossFade())
//                    .centerCrop()
//                    .into(imgItemPhoto)
//                tvItem.text = user.login
//            }
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val view = ItemUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FavoriteViewHolder(view)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        holder.bind(list[position])
    }
    interface OnItemClickCallback {
        fun onItemClicked(data: FavoriteUser)
    }
}